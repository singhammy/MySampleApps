﻿

using SampleCoreWebAPI.Models;
using System.Collections.Generic;
using System.Linq;

namespace SampleCoreWebAPI.ProductData
{
    public class MockProductData : IProductData
    {
        private List<Product> products = new List<Product>()
        {
            new Product()
            {
                Ean = "ean1",
                Price = 99.95
            },
            new Product()
            {
                Ean = "ean2",
                Price = 16.15
            },
            new Product()
            {
                Ean = "ean3",
                Price = 12
            }
        };

    
        public List<Product> GetProdtucts()
        {
            return products;
        }

        public Product GetProductByCode(string code)
        {
            return products.SingleOrDefault(x => x.Ean == code);
        }

        public void AddProduct(Product product)
        {
            products.Add(product);
        }

        public void DeleteProduct(string code)
        {
            products.RemoveAll(x => x.Ean == code);
        }

        public void EditProduct(string code, Product product)
        {
            Product existingProduct = GetProductByCode(code);
            existingProduct.Price = product.Price;
        }

      
    }
}
