﻿using SampleCoreWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SampleCoreWebAPI.ProductData
{
    public interface IProductData
    {
        List<Product> GetProdtucts();

        Product GetProductByCode(string code);

        void AddProduct(Product product);

        void DeleteProduct(string code);

        void EditProduct(string code, Product product);
    }
}
