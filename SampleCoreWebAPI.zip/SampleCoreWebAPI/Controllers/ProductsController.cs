﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using SampleCoreWebAPI.ProductData;
using SampleCoreWebAPI.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SampleCoreWebAPI.Controllers
{
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private IProductData _productData;
        public ProductsController(IProductData productData)
        {
            _productData = productData;
        }

        [HttpGet]
        [Route("api/[controller]")]
        public IActionResult GetProducts()
        {
            return Ok(_productData.GetProdtucts());
        }

        [HttpGet]
        [Route("api/[controller]/{code}")]
        public IActionResult GetPriceByCode(string code)
        {
            Product product  = _productData.GetProductByCode(code);
            if(product != null)
            {
                return Ok(product.Price);
            }
            return NotFound($"product {code} not found");          
        }

        [HttpPost]
        [Route("api/[controller]")]
        public IActionResult AddProduct(Product product)
        {
           _productData.AddProduct(product);
            return Ok("product successfully added");
        }

        [HttpDelete]
        [Route("api/[controller]/{code}")]
        public IActionResult DeleteProduct(string code)
        {
            Product product = _productData.GetProductByCode(code);
            if (product != null)
            {
                _productData.DeleteProduct(code);
                return Ok("product successfully Deleted");
            }
            return NotFound($"product {code} does not exist");
        }

        [HttpPatch]
        [Route("api/[controller]/{code}")]
        public IActionResult EditProduct(string code, Product product)
        {
            Product existingProduct = _productData.GetProductByCode(code);
            if (existingProduct != null)
            {
                _productData.EditProduct(code, product);
                return Ok("product updated successfully");
            }
            return NotFound($"product {code} does not exist");
        }
    }
}
